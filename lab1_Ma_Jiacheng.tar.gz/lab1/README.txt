ex.bash is shell file to conduct experiment. It generates output file for plot.
plot folder contains data figures of experiments.

The benchmark tests is in Task_2/inputs/memory_access

Task_2/sim_dr/ contains the compiled sim for different cache settings.
