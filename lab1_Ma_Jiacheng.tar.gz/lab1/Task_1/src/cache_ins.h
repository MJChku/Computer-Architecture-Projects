#ifndef _CACHE_INS_H_
#define _CACHE_INS_H_

uint32_t cache_ins_read_32(uint32_t address);
void init_cache_ins();

#endif